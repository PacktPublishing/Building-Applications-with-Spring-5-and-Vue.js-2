package com.taskagile.domain.model.user;

public class UserNotFoundException extends Exception {

  private static final long serialVersionUID = -6826272470679025298L;

}
