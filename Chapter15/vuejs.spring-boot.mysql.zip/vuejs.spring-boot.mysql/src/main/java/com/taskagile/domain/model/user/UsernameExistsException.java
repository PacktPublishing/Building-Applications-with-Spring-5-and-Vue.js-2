package com.taskagile.domain.model.user;

public class UsernameExistsException extends RegistrationException {

  private static final long serialVersionUID = -7856406258381199164L;

}
