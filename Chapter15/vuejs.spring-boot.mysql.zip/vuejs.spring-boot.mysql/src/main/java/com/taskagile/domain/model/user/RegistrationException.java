package com.taskagile.domain.model.user;

public class RegistrationException extends Exception {

  private static final long serialVersionUID = -2737904013752279210L;

}
