module.exports = {
  url: function () {
    return this.api.launchUrl
  },
  elements: {
    logoImage: {
      selector: '.logo img'
    }
  }
}
