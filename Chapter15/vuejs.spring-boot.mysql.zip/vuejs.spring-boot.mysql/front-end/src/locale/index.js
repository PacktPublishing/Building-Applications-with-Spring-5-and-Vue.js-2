import enUSMessages from './messages/en_US.json'
import zhCNMessages from './messages/zh_CN.json'

export const enUS = enUSMessages
export const zhCN = zhCNMessages
