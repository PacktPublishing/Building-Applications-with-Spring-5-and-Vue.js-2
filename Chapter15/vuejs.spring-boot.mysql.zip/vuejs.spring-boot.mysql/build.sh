# Local build command include local e2e testing
mvn clean install -P local-e2e
